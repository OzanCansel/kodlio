#include<Arduino.h>

void setup();
void loop();

void setup()
{
pinMode(10, OUTPUT);
}

void loop()
{
analogWrite(10, 155);
}